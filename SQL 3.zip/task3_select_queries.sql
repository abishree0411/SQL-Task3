-- Select all employees
SELECT * FROM employees;

-- Select specific columns
SELECT first_name, last_name, salary FROM employees;

-- Filter by department
SELECT * FROM employees
WHERE department = 'IT';

-- Filter by department and salary
SELECT * FROM employees
WHERE department = 'IT' AND salary > 63000;

-- OR condition
SELECT * FROM employees
WHERE department = 'HR' OR hire_date > '2022-01-01';

-- Pattern matching
SELECT * FROM employees
WHERE last_name LIKE 'J%';

-- Date range filtering
SELECT * FROM employees
WHERE hire_date BETWEEN '2020-01-01' AND '2022-12-31';

-- Sorting
SELECT * FROM employees
ORDER BY salary ASC;

-- Sorting by date
SELECT * FROM employees
ORDER BY hire_date DESC;

-- Limiting results
SELECT * FROM employees
ORDER BY salary DESC
LIMIT 2;
